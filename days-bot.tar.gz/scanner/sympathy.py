"""
sympathy.py
-----------
For each candidate, identify the sector Leader (biggest gap in same sector).
Mark candidates as Sympathy Plays and boost their score accordingly.
"""

import pandas as pd


def tag_sympathy(candidates: pd.DataFrame) -> pd.DataFrame:
    """
    Adds columns:
    - is_leader   (bool)   — highest gap in its sector
    - is_sympathy (bool)   — not the leader but in same sector/industry as leader
    - leader      (str)    — ticker of the sector leader
    - reason      (str)    — human-readable label for the alert
    """
    if candidates.empty:
        return candidates

    df = candidates.copy()
    df["is_leader"]   = False
    df["is_sympathy"] = False
    df["leader"]      = ""
    df["reason"]      = "Momentum Play"

    # Find the leader per sector (highest gap_pct)
    sector_leaders = (
        df.loc[df.groupby("sector")["gap_pct"].idxmax()]
        [["sector", "ticker", "gap_pct"]]
        .rename(columns={"ticker": "leader_ticker", "gap_pct": "leader_gap"})
    )

    df = df.merge(sector_leaders, on="sector", how="left")

    for idx, row in df.iterrows():
        if row["ticker"] == row["leader_ticker"]:
            df.at[idx, "is_leader"] = True
            df.at[idx, "reason"]    = f"Sector Leader ({row['sector']})"
        else:
            # Sympathy = same sector, leader has significantly bigger gap
            if row["leader_gap"] >= row["gap_pct"] * 1.5:
                df.at[idx, "is_sympathy"] = True
                df.at[idx, "leader"]      = row["leader_ticker"]
                df.at[idx, "reason"]      = (
                    f"Sympathy Play → {row['leader_ticker']} +{row['leader_gap']:.1f}%"
                )

    df.drop(columns=["leader_ticker", "leader_gap"], inplace=True)
    print(f"[Sympathy] Leaders: {df['is_leader'].sum()} | Sympathy: {df['is_sympathy'].sum()}")
    return df
