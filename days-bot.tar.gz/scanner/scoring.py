"""
scoring.py
----------
Calculates a 0-100 composite score for each candidate.

Weights:
  Volume Score   30  — vol_ratio vs 30-day avg
  Gap Score      20  — gap_pct size
  Sector Score   20  — leader/sympathy bonus
  Price Score    10  — sweet-spot pricing ($2-$10 scores highest)
  Momentum Score 20  — gap × volume combined signal
"""

import pandas as pd
import numpy as np


def _norm(series: pd.Series, lo: float, hi: float) -> pd.Series:
    """Clip and normalise a series to [0, 1]."""
    clipped = series.clip(lo, hi)
    return (clipped - lo) / (hi - lo) if hi > lo else pd.Series(0.0, index=series.index)


def score_candidates(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df

    out = df.copy()

    # --- Volume Score (30 pts) ---
    # vol_ratio of 5x = full marks; 1x = 0
    out["vol_score"] = (_norm(out["vol_ratio"], 1, 10) * 30).round(1)

    # --- Gap Score (20 pts) ---
    # 5% gap = 0 pts; 30%+ gap = full 20 pts
    out["gap_score"] = (_norm(out["gap_pct"], 5, 30) * 20).round(1)

    # --- Sector Score (20 pts) ---
    # Leader = 20, Sympathy = 14, Other = 0
    out["sector_score"] = np.where(
        out["is_leader"],   20,
        np.where(out["is_sympathy"], 14, 0)
    )

    # --- Price Score (10 pts) ---
    # Sweet spot $2-$10 (most day-trader friendly)
    def price_pts(p):
        if 2 <= p <= 10:
            return 10
        elif 10 < p <= 15:
            return 6
        elif 1 <= p < 2:
            return 4
        return 2

    out["price_score"] = out["price"].apply(price_pts)

    # --- Momentum Score (20 pts) ---
    # Combined log signal: log(gap * volume)
    momentum_raw = np.log1p(out["gap_pct"] * out["vol_ratio"])
    out["momentum_score"] = (_norm(momentum_raw, 0, np.log1p(30 * 15)) * 20).round(1)

    # --- Total ---
    out["score"] = (
        out["vol_score"]
        + out["gap_score"]
        + out["sector_score"]
        + out["price_score"]
        + out["momentum_score"]
    ).round(1)

    out.sort_values("score", ascending=False, inplace=True)
    out.reset_index(drop=True, inplace=True)

    print(f"[Scoring] Top score: {out['score'].iloc[0]:.1f} ({out['ticker'].iloc[0]})")
    return out
