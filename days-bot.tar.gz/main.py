"""
main.py
-------
DAYS-BOT V1 Orchestrator.

Run modes (detected automatically by UTC time):
  07:30 ET  (12:30 UTC)  → build_universe + premarket scan
  08:45 ET  (13:45 UTC)  → score + sympathy tag + send alerts
  Any other time         → full pipeline (for manual / workflow_dispatch runs)
"""

import sys
from datetime import datetime, timezone

import pytz

from scanner.universe  import build_universe, load_universe
from scanner.premarket import scan_premarket
from scanner.sympathy  import tag_sympathy
from scanner.scoring   import score_candidates
from database.db       import init_db, save_alert, already_sent_today
from telegram.sender   import send_message, format_alert
from utils.config      import TELEGRAM_TOKEN, TELEGRAM_CHAT_ID, MIN_SCORE

ET = pytz.timezone("America/New_York")


def run_universe_build():
    print("=== [DAYS-BOT] Phase 1: Building Universe ===")
    build_universe()


def run_alert_pipeline():
    print("=== [DAYS-BOT] Phase 2: Scan + Score + Alert ===")

    init_db()
    today = datetime.now(ET).strftime("%Y-%m-%d")

    universe   = load_universe()
    candidates = scan_premarket(universe)

    if candidates.empty:
        print("[Main] No candidates passed premarket filter. Exiting.")
        send_message(TELEGRAM_TOKEN, TELEGRAM_CHAT_ID,
                     f"🤖 DAYS-BOT {today}\nNo candidates above threshold today.")
        return

    candidates = tag_sympathy(candidates)
    candidates = score_candidates(candidates)

    # Filter by minimum score
    top = candidates[candidates["score"] >= MIN_SCORE].head(5)

    if top.empty:
        print(f"[Main] No candidates scored above {MIN_SCORE}.")
        return

    sent = 0
    for _, row in top.iterrows():
        ticker = row["ticker"]
        if already_sent_today(today, ticker):
            print(f"[Main] {ticker} already sent today — skipping.")
            continue

        msg = format_alert(row.to_dict())
        ok  = send_message(TELEGRAM_TOKEN, TELEGRAM_CHAT_ID, msg)

        if ok:
            save_alert(today, row.to_dict())
            sent += 1
            print(f"[Main] ✅ Sent alert for {ticker} (score={row['score']:.1f})")
        else:
            print(f"[Main] ❌ Failed to send {ticker}")

    print(f"[Main] Done. {sent} alert(s) sent.")


def detect_mode() -> str:
    """Return 'universe', 'alerts', or 'full' based on current ET time."""
    now_et = datetime.now(ET)
    hour, minute = now_et.hour, now_et.minute

    # 07:25–07:45 ET → universe build window
    if hour == 7 and 25 <= minute <= 45:
        return "universe"

    # 08:40–09:00 ET → alert send window
    if hour == 8 and 40 <= minute <= 59:
        return "alerts"
    if hour == 9 and minute == 0:
        return "alerts"

    return "full"


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else detect_mode()
    print(f"[Main] Mode: {mode}")

    if mode == "universe":
        run_universe_build()
    elif mode == "alerts":
        run_alert_pipeline()
    else:
        run_universe_build()
        run_alert_pipeline()
